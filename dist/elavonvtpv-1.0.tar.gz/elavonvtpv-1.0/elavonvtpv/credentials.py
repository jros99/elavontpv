MERCHANT_ID = 'zertifica'
SECRET = 'secreto'
ACCOUNTS = [
    'internet',
]
