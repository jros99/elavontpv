from xml.dom import minidom
import elavonvtpv.enum as elavon_enum
import elavonvtpv.CreditCard as cc
import elavonvtpv.TssInfo as tss
import elavonvtpv.Request as req
import elavonvtpv.credentials as credentials
import requests

url_test = {
    'redirect':'https://hpp.prueba.santanderelavontpvvirtual.es/pay',
    'remote':'https://remote.prueba.santanderelavontpvvirtual.es/remote'
}

test_credit_cards = {
    'VISA': [
        {
            'number': '4263970000005262',
            'result': '00',
            'message': 'Autorizada',
        },
        {
            'number': '4000120000001154',
            'result': '101',
            'message': 'Declinada',
        },
        {
            'number': '4000130000001724',
            'result': '102',
            'message': 'Referral B',
        },
        {
            'number': '4000160000004147',
            'result': '103',
            'message': 'Referral A',
        },
        {
            'number': '4009830000001985',
            'result': '205',
            'message': 'Error de comunicación',
        }
    ],
    'MC': [
        {
            'number': '5425230000004415',
            'result': '00',
            'message': 'Autorizada',
        },
        {
            'number': '5114610000004778',
            'result': '101',
            'message': 'Declinada',
        },
        {
            'number': '5114630000009791',
            'result': '102',
            'message': 'Referral B',
        },
        {
            'number': '5121220000006921',
            'result': '103',
            'message': 'Referral A',
        },
        {
            'number': '5135020000005871',
            'result': '205',
            'message': 'Error de comunicación',
        }
    ],
    'AMEX': [
        {
            'number': '374101000000608',
            'result': '00',
            'message': 'Autorizada',
        },
        {
            'number': '375425000003',
            'result': '101',
            'message': 'Declinada',
        },
        {
            'number': '375425000000907',
            'result': '102',
            'message': 'Referral B',
        },
        {
            'number': '343452000000306',
            'result': '103',
            'message': 'Referral A',
        },
        {
            'number': '372349000000852',
            'result': '205',
            'message': 'Error de comunicación',
        }
    ]
}

credit_card = cc.CreditCard(
    cvn_indicator=cc.CVNIndicator.present,
    number='',
    expiry='1218',
    name='Filiberto Pruebas de Tests',
    card_type=elavon_enum.CardType.visa,
    cvn=str(123),
)

tss_info = tss.TssInfo(
    customer_number='01',
    product_id='ZERES',
    variable_reference='0',
    customer_ip='192.168.1.45',
    billing_code='18690',
    billing_country='Spain',
    shipping_code='18690',
    shipping_country='Spain'
)

request = req.Request(
    secret=credentials.SECRET,
    request_type=elavon_enum.RequestType.auth,
    merchant_id=credentials.MERCHANT_ID,
    order_id='ZER0ES',
    currency=elavon_enum.Currency.euro,
    amount=str(2000),
    card=credit_card,
    tss_info=tss_info,
    settle=True,
    account=credentials.ACCOUNTS[0],
    channel=elavon_enum.Channel.e_commerce,
    comment1='Esto es una prueba',
    comment2='Esto es una prueba',
    past_reference='referencia del pasado',
    authorization_code='authorization-code-12344',
    refund_hash='fluhlkghfluthguiw9545075860896758963',
)

# test_card = test_credit_cards['VISA'][0]
i = 5
for card_type, contents in test_credit_cards.items():
    if card_type == 'VISA':
        credit_card.card_type = elavon_enum.CardType.visa
    elif card_type == 'MC':
        credit_card.card_type = elavon_enum.CardType.mastercard
    elif card_type == 'AMEX':
        credit_card.card_type = elavon_enum.CardType.american_express
    for test_card in contents:
        request.order_id = 'PRUEBA' + str(i)
        credit_card.number = test_card['number']
        print(minidom.parseString(request.to_xml_string()).toprettyxml())
        response = request.send(url=url_test['remote'])
        print(response.result)
        print(response.message)
        print('--------------------------------------------------------------------------------------')
        # if response.result == test_card['result']:
        #     print(response.validate_origin(credentials.SECRET))
        i += 1
